# NB Tech Support provide  Steps to  depoly the files and complete the task
# Check this blog https://www.nbtechsupport.co.in
# Go through Youtube Channel for Devops & Linux Task [**link to Youtube Task!**](https://www.youtube.com/channel/UCgrAoSs9Xl94UZjAwuznfWQ?sub_confirmation=1) 
# Feel free to ask any questions you may have while going through tasks and get your doubts cleared.
# Happy Learning !!!
